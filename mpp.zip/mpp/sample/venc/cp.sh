ifconfig eth0 192.168.1.14
cd /mnt
cp sample_venc /usr/share/ -rf
udhcpc
cd /usr/share