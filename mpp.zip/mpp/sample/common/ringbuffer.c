#include "ringbuffer/ringbuffer.h"
#include <stdio.h>
#include "sample_comm.h"
#define DataBufferForCutSize 200000
unsigned char *DataBufferForCut;
ring_buffer_t Ring_buffer;
ring_buffer_size_t data_size;       // Stores the size of the data stored in the ring buffer each time
ring_buffer_size_t get_data_size;   // The size of data fetched from the ring buffer at a time
data_info info;                     //The location and size of the data retrieved from the ring buffer  
static inline int pows(int num_,int i_)
{
    int ret=1;
    while(i_>0){
        i_--;
        ret=num_*ret;
    }
    return ret;
}
void ring_buffer_init(ring_buffer_t *ring_buffer)
{
    ring_buffer->head_index=0;
    ring_buffer->tail_index=0;
    /* Allocate memory space for ring buffers */
    ring_buffer->buffer=malloc(RING_BUFFER_SIZE);
    if(NULL==ring_buffer->buffer)
    {
        printf("malloc buffer failed");
        exit(0);
    }
    ring_buffer->remainsize=RING_BUFFER_SIZE;
    /* init mutex */
    pthread_mutex_init(&(ring_buffer->mutex), NULL);    
    sem_init(&(ring_buffer->sem),0,0);
    DataBufferForCut=malloc(DataBufferForCutSize);
}

void ring_buffer_destory(ring_buffer_t *ring_buffer)
{
    /* Free memory space for ring buffers */
    free(ring_buffer->buffer);
    /* destory mutex */ 
    pthread_mutex_destroy(&(ring_buffer->mutex));

}

/**
 * reserve some buffer for queue 
*/
int ring_buffer_reserve(ring_buffer_t *ring_buffer,ring_buffer_size_t size)
{
    int ret;
    pthread_mutex_lock(&(ring_buffer->mutex)); 
    if(ring_buffer->remainsize>=size)
    {
        ring_buffer->remainsize-=size;
        ret=1;
    }
    else
    {
        ret=0;
    } 
    pthread_mutex_unlock(&(ring_buffer->mutex));
    return ret;  
}

/**
 * Release the ring buffer that has been read
*/
void ring_buffer_free(ring_buffer_t *ring_buffer,ring_buffer_size_t size)
{
    pthread_mutex_lock(&(ring_buffer->mutex)); 
    ring_buffer->remainsize+=size;     
    pthread_mutex_unlock(&(ring_buffer->mutex));
}   

void ring_buffer_queue_arr(ring_buffer_t *ring_buffer, unsigned char *data, ring_buffer_size_t size)
{
    volatile int head_to_end,j,i;
    char *p=ring_buffer->buffer+ring_buffer->head_index;
    if(ring_buffer_reserve(ring_buffer,size+4)==0)
    {
        printf("Insufficient ring buffer space \n");
        return;
    }
    data_size=size;
    if(ring_buffer->head_index+size+4<=RING_BUFFER_SIZE-1)
    {
        j=size;
        for(i=0;i<4;i++)
        {
            *(p+i)=j%255;
            j=j/255;
        }
        *(p+3)=IsFbEnd;
        memcpy(ring_buffer->buffer+ring_buffer->head_index+4,data,data_size); 
        ring_buffer->head_index=ring_buffer->head_index+data_size+4;
    }  
    else
    {
        j=size;
        head_to_end=RING_BUFFER_SIZE-ring_buffer->head_index;
        if(head_to_end>=4)
        {
            for(i=0;i<4;i++)
            {
                *(p+i)=j%255;
                j=j/255;
            }
            *(p+3)=IsFbEnd;
            memcpy(ring_buffer->buffer+ring_buffer->head_index+4,data,head_to_end-4);
            memcpy(ring_buffer->buffer,data+head_to_end-4,size-head_to_end+4);
        }
        else
        {
            for(i=0;i<head_to_end;i++)
            {
                *(p+i)=j%255;
                j=j/255;
            }
            p=ring_buffer->buffer;
            for(i=0;i<(4-head_to_end);i++)
            {
                *(p+i)=j%255;
                j=j/255;
            }
            *(p+4-head_to_end-1)=IsFbEnd;
            memcpy(ring_buffer->buffer+4-head_to_end,data,size);
        }
        ring_buffer->head_index=size+4-head_to_end;
    }

    //printf("                                                head pos:%d \n",ring_buffer->head_index);
    sem_post(&ring_buffer->sem);
}

char is_to_end(ring_buffer_t *ring_buffer, ring_buffer_size_t size)
{
   
    if(ring_buffer->tail_index+size<=RING_BUFFER_SIZE-1)
        return 0;
    else
        return 1;  
}

inline void clear_info(void)
{
  info.point_1=NULL;
  info.point_2=NULL;
  info.size_1=0;
  info.size_2=0;
  info.final_tail_position=0;
  info.is_two=0;
}


void cut_ring_buffer_dequeue_arr(ring_buffer_t *ring_buffer, ring_buffer_size_t size)
{
    /* The first point out of the queue */
    info.point_1=ring_buffer->buffer+ring_buffer->tail_index;
    info.size_1=RING_BUFFER_SIZE-ring_buffer->tail_index;
    /* The second point out of the queue */
    info.point_2=ring_buffer->buffer;
    info.size_2=size-info.size_1;
    /* The final position of the tail_index */
    info.final_tail_position=info.size_2;
    info.is_two=1;
    
}

void get_ringbuffer_data_info(ring_buffer_t *ring_buffer)
{  
    sem_wait(&ring_buffer->sem);
     char *p;int i;
    // Step 1: get the data size
    
    get_data_size=0;
    if(is_to_end(ring_buffer,4)){
        cut_ring_buffer_dequeue_arr(ring_buffer,4);
        p=info.point_1;
        for(i=0;i<info.size_1;i++)
        {
            if(i==3)
                IsFbEndSend=*(p+i);
            else   
                get_data_size+=(int)*(p+i)*pows(255,i);
        }
        p=info.point_2;
        for(i=0;i<info.size_2;i++)
        {
            if((i+info.size_1)==3)
                IsFbEndSend=*(p+i);
            else  
                get_data_size+=(int)*(p+i)*pows(255,i+info.size_1);
        }
        ring_buffer->tail_index=info.final_tail_position;  
    }
    else
    {
        p=ring_buffer->buffer+ring_buffer->tail_index;
        get_data_size=((int)*(p+2))*65025+((int)*(p+1))*255+(int)*(p);
        IsFbEndSend=(int)*(p+3);
        ring_buffer->tail_index+=4;
    }
    clear_info();

    // Step 2: get the data position
    if(is_to_end(ring_buffer,get_data_size))
    {
        cut_ring_buffer_dequeue_arr(ring_buffer,get_data_size);
    }
    else
    {
        info.point_1=ring_buffer->buffer+ring_buffer->tail_index;
        info.size_1=get_data_size;
        info.size_2=0;
        info.final_tail_position=ring_buffer->tail_index+get_data_size;
        info.is_two=0;
    }    
    ring_buffer->tail_index=info.final_tail_position; 
}



