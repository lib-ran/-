#include <stdio.h>
#include <stdlib.h>
#include "rtmp.h"     
#include "amf.h" 
#include <unistd.h>
#include "rtmp_h264_send.h" 
#include <string.h>
#define MaxBodySize 1024*300
#define DefauleRtmpTimestampAdd0 33
#define DefauleRtmpTimestampAdd1 34
/*Internal use */
unsigned int timestamporder=0;
RTMP *m_pRtmp;
RTMPPacket *Packet;
unsigned int RTMPTimestamp;  
static RTMPPacket* Packet_Alloc(void)
{
    RTMPPacket* p=(RTMPPacket*)malloc(sizeof(RTMPPacket));
    return p;
}
static void PacketInit(RTMPPacket *packet)
{
    packet->m_body=malloc(MaxBodySize);
}

static void PacketFree(RTMPPacket *packet)
{
    if(packet)
        if(packet->m_body)
            free(packet->m_body);
}

/* External use */
int RTMP264_Connect(const char* url)  
{  
      
	m_pRtmp = RTMP_Alloc();
    Packet  = Packet_Alloc(); 
	RTMP_Init(m_pRtmp);
    RTMPTimestamp=0;
    PacketInit(Packet); 
	/*设置URL*/
	if (RTMP_SetupURL(m_pRtmp,(char*)url) == FALSE)
	{
		RTMP_Free(m_pRtmp);
        PacketFree(Packet);
		return 0;
	}
    printf("set url ok ..... \n");
	RTMP_EnableWrite(m_pRtmp);
	/*连接服务器*/
	while(RTMP_Connect(m_pRtmp, NULL) == FALSE) 
	{
		sleep(1);
        printf("connect server failed ..... \n");
		//exit(0);
	}

    printf("connect server ok ..... \n");
    

	/*连接流*/
	if (RTMP_ConnectStream(m_pRtmp,0) == FALSE)
	{
		RTMP_Close(m_pRtmp);
		RTMP_Free(m_pRtmp);
        PacketFree(Packet);
		return 0;
	}
    else
    {
        printf("build stream ok ..... \n");
    }
	return 1;  
} 

void RTMP264_Free(void)
{
	if(m_pRtmp)
    {
        RTMP_Close(m_pRtmp);
	    RTMP_Free(m_pRtmp);
    }
    if(Packet)
    {
        PacketFree(Packet); 
    }
}

typedef struct NALinfo NALinfo;
struct NALinfo{
    unsigned int NALtype;
    unsigned char* H264;
};

static unsigned char startCode3(unsigned char* h264)
{
    if(h264[0] == 0 && h264[1] == 0 && h264[2] == 1)
        return 1;
    else
        return 0;
}
static unsigned char startCode4(unsigned char* h264)
{   
    if(h264[0] == 0 && h264[1] == 0 && h264[2] == 0 && h264[3] == 1)
        return 1;
    else
        return 0;
}
/* Used to get the location and type of nal package */
static NALinfo GetOneNALFromBuf(unsigned char* H264,unsigned int Totalsize)
{
    NALinfo nalinfo;
    if(startCode3(H264))
    {
        nalinfo.H264=H264+3;
        nalinfo.NALtype=(*nalinfo.H264)&0x1f;
        return nalinfo;
    }
    else if(startCode4(H264))
    {
        nalinfo.H264=H264+4;
        nalinfo.NALtype=(*nalinfo.H264)&0x1f;
        return nalinfo;       
    }
    else
    {
        nalinfo.NALtype=66;
        return nalinfo;
    }
}

/* External use */  

void RtmpSendH264(unsigned char* H264,unsigned int Totalsize){

    unsigned int NALsize,bodysize;
    static unsigned int i=0;
    unsigned char *NALdata;
    //get nal info 
    NALinfo nalinfo=GetOneNALFromBuf(H264,Totalsize); 
    //get nal size            
    NALsize=((nalinfo.NALtype==3)?(Totalsize-3):(Totalsize-4)); 
    //get real naldata
    NALdata=nalinfo.H264;   

    //is I frame or P frame
    if(nalinfo.NALtype==0x05||nalinfo.NALtype==0x01)
    {  
        // I Frame
        if(nalinfo.NALtype==0x05)
        {
            Packet->m_body[0] = 0x17;// 1:Iframe  7:AVC   
            Packet->m_body[1] = 0x01;// AVC NALU   
            Packet->m_body[2] = 0x00;  
            Packet->m_body[3] = 0x00;  
            Packet->m_body[4] = 0x00;  
            // NALU size   
            Packet->m_body[5] = NALsize>>24 &0xff;  
            Packet->m_body[6] = NALsize>>16 &0xff;  
            Packet->m_body[7] = NALsize>>8 &0xff;  
            Packet->m_body[8] = NALsize&0xff;
            memcpy(&Packet->m_body[9],NALdata,NALsize);
        }
        // P Frame
        if(nalinfo.NALtype==0x01)
        {
            Packet->m_body[0] = 0x27;// 2:Pframe  7:AVC   
            Packet->m_body[1] = 0x01;// AVC NALU   
            Packet->m_body[2] = 0x00;  
            Packet->m_body[3] = 0x00;  
            Packet->m_body[4] = 0x00; 

            // NALU size   
            Packet->m_body[5] = NALsize>>24 &0xff;  
            Packet->m_body[6] = NALsize>>16 &0xff;  
            Packet->m_body[7] = NALsize>>8 &0xff;  
            Packet->m_body[8] = NALsize&0xff;
            memcpy(&Packet->m_body[9],NALdata,NALsize);
        }
        // frametype|CodeID (1byte) / Packetype(1byte) / CompositionTime (3byte) / NALlen (4byte) / NALdata(NALsize byte) /
        bodysize=9+NALsize;
        Packet->m_nBodySize =bodysize;
        Packet->m_hasAbsTimestamp = 0;
        Packet->m_packetType = 0x09; /*此处为类型有两种一种是音频,一种是视频*/
        Packet->m_nInfoField2 = m_pRtmp->m_stream_id;
        Packet->m_nChannel = 0x04;
        Packet->m_headerType = RTMP_PACKET_SIZE_LARGE;
        Packet->m_nTimeStamp = RTMPTimestamp;
        RTMP_SendPacket(m_pRtmp, Packet,0);
        if(timestamporder>=3){
            RTMPTimestamp+=DefauleRtmpTimestampAdd1;
            timestamporder=0;
        }
        else
        {
            RTMPTimestamp+=DefauleRtmpTimestampAdd0;
            timestamporder++;
        }
        
    }


     //is SPS or PPS
    if(nalinfo.NALtype==0x07||nalinfo.NALtype==0x08)
    {
        // SPS
        if(nalinfo.NALtype==0x07)   
        {
                 //如果是PPS SPS.....
            Packet->m_body[0] = 0x17;// 1:keyframe  7:AVC   
            Packet->m_body[1] = 0x00;// AVC SEQ   
            Packet->m_body[2] = 0x00;  
            Packet->m_body[3] = 0x00;  
            Packet->m_body[4] = 0x00; 
            /*AVCDecoderConfigurationRecord*/
            i=5;
            Packet->m_body[i++] = 0x01;
            Packet->m_body[i++] = NALdata[1];
            Packet->m_body[i++] = NALdata[2];
            Packet->m_body[i++] = NALdata[3];
            Packet->m_body[i++] = 0xff;
            /*sps*/
            Packet->m_body[i++]   = 0xe1;
            Packet->m_body[i++] = (NALsize >> 8) & 0xff;
            Packet->m_body[i++] = NALsize & 0xff;
            memcpy(&Packet->m_body[i],NALdata,NALsize);
            i += NALsize;   
        }

        // PPS
        if(nalinfo.NALtype==0x08)
        {    
            // Ensure that the last frame is SPS
            if(Packet->m_body[0] != 0x17||Packet->m_body[1] != 0x00)
            {
                return ;
            }
            Packet->m_body[i++]   = 0x01;
            Packet->m_body[i++] = (NALsize >> 8) & 0xff;
            Packet->m_body[i++] = (NALsize) & 0xff;
            memcpy(&Packet->m_body[i],NALdata,NALsize);
            i +=  NALsize;
            Packet->m_packetType = 0x09;
            Packet->m_nBodySize = i;
            Packet->m_nChannel = 0x04;
            Packet->m_nTimeStamp = RTMPTimestamp;
            Packet->m_hasAbsTimestamp = 0;
            Packet->m_headerType = RTMP_PACKET_SIZE_MEDIUM;
            Packet->m_nInfoField2 = m_pRtmp->m_stream_id;
            RTMP_SendPacket(m_pRtmp, Packet,0);
        }   
    }
}