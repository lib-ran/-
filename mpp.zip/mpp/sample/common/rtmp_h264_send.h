#ifndef RTMP_SEND_H264
#define RTMP_SEND_H264

extern unsigned int RTMPTimestamp;
int RTMP264_Connect(const char* url);

void RtmpSendH264(unsigned char* H264,unsigned int Totalsize);

void RTMP264_Free(void);

#endif