#ifndef RINGBUFFER_H
#define RINGBUFFER_H
#define RING_BUFFER_SIZE 1024*1024
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
typedef  int ring_buffer_size_t;
typedef struct ring_buffer_t ring_buffer_t;
typedef struct data_info data_info;
struct ring_buffer_t {
  /** Buffer memory. */
  char *buffer;
  /** Index of tail. */
  ring_buffer_size_t tail_index;
  /** Index of head. */
  ring_buffer_size_t head_index;
  /** remainsize of ringbuffer. */
  ring_buffer_size_t remainsize;
  /** mutex for protect “remainsize” variable */
  pthread_mutex_t mutex;
  /* Semaphores are used to inform other threads that data is ready */
  sem_t sem;
};
struct data_info{
    char is_two;
    char *point_1;
    int  size_1;
    char *point_2;
    int  size_2;
    int  final_tail_position;
};
extern ring_buffer_t Ring_buffer;
extern ring_buffer_size_t data_size;
extern ring_buffer_size_t get_data_size;
extern data_info info;
extern unsigned char *DataBufferForCut;
inline void clear_info(void);


void ring_buffer_init(ring_buffer_t *ring_buffer);
void ring_buffer_destory(ring_buffer_t *ring_buffer);

void ring_buffer_queue_arr(ring_buffer_t *ring_buffer, unsigned char *data, ring_buffer_size_t size);   
char is_to_end(ring_buffer_t *ring_buffer, ring_buffer_size_t size);
void cut_ring_buffer_dequeue_arr(ring_buffer_t *ring_buffer, ring_buffer_size_t size);
void get_ringbuffer_data_info(ring_buffer_t *ring_buffer);


/**
 * reserve some buffer for queue 
*/
int ring_buffer_reserve(ring_buffer_t *ring_buffer,ring_buffer_size_t size);

/**
 * Release the ring buffer that has been read
*/
void ring_buffer_free(ring_buffer_t *ring_buffer,ring_buffer_size_t size);

#endif